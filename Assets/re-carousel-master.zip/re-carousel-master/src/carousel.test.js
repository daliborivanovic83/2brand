import React from 'react'
import ReactDOM from 'react-dom'
import Carousel from './carousel'

global.it('renders 1 frame without crashing', () => {
  const div = document.createElement('div')
  ReactDOM.render((
    <Carousel loop auto axis={'x'}>
      <p style={{backgroundColor: 'orange', height: '100%'}}>FRAME 2</p>
    </Carousel>
  ), div)
})

global.it('renders 2 frames without crashing', () => {
  const div = document.createElement('div')
  ReactDOM.render((
    <Carousel loop auto axis={'x'}>
      <p style={{backgroundColor: 'orange', height: '100%'}}>FRAME 2</p>
      <p style={{backgroundColor: 'orchid', height: '100%'}}>FRAME 3</p>
    </Carousel>
  ), div)
})

global.it('renders without crashing', () => {
  const div = document.createElement('div')
  ReactDOM.render((
    <Carousel loop auto axis={'x'}>
      <p style={{backgroundColor: 'royalblue', height: '100%'}}>FRAME 1</p>
      <p style={{backgroundColor: 'orange', height: '100%'}}>FRAME 2</p>
      <p style={{backgroundColor: 'orchid', height: '100%'}}>FRAME 3</p>
    </Carousel>
  ), div)
})
